//
//  CandyBustVC.swift
//  Animation
//
//  Created by hb on 08/09/23.
//

import UIKit
import Hero

class CandyBustVC: UIViewController {
    
    //MARK: IBoutlates
    
    @IBOutlet weak var yellowView: UIView!
    @IBOutlet weak var didTapGreen: UIView!
    @IBOutlet weak var lblText: UILabel!
    @IBOutlet weak var btnReadMore: UIButton!
    @IBOutlet weak var btnCross: UIButton!
    @IBOutlet weak var grayLeftView: UIView!
    @IBOutlet weak var grayRightView: UIView!
    @IBOutlet weak var lblDownload: UILabel!
    @IBOutlet weak var lblMB: UILabel!
    @IBOutlet weak var mainGrayView: UIView!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var btnGreenButtom: UIButton!
    @IBOutlet weak var dataStck: UIStackView!
    @IBOutlet weak var btnCheck: UIButton!
    @IBOutlet weak var viewPay: UIView!
    @IBOutlet weak var btnPlay: UIButton!
    
    //MARK: Variables Declaration
    
    var isRed = false
    var progressBarTimer: Timer!
    var isRunning = false
    
    //MARK: ViewLive Cycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.navigationItem.hidesBackButton = true
        setupUi()
    }
    
    //MARK: SetupUi Method
    
    func setupUi() {
        progressView.progress = 0.0
        yellowView.layer.cornerRadius = 25
        btnCheck.layer.cornerRadius = 25
        btnGreenButtom.layer.cornerRadius = 25
        progressView.layer.cornerRadius = 25
        progressView.clipsToBounds = true
      
        self.hero.isEnabled = true
        self.navigationController?.hero.isEnabled = true
        yellowView.hero.id = "YellowAnimation"
        didTapGreen.hero.id = "GreenAnimation"
        progressView.transform = CGAffineTransform(translationX: 30, y: 0)
        mainGrayView.transform = CGAffineTransform(translationX: self.view.frame.width, y: 0)
        lblText.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        btnReadMore.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        
        btnCross.transform = CGAffineTransform(translationX: 0, y: self.btnCross.frame.height)
        
        UIView.animate(withDuration: 0.8, delay: 0, options: .curveEaseIn) {
            self.mainGrayView.transform = .identity
           
        }
        UIView.animate(withDuration: 2.0) {
            self.lblText.transform = .identity
            self.btnReadMore.transform = .identity
            self.btnCross.transform = .identity
        }
        
    }
    
    @objc func updateProgressView(){
        UIView.animate(withDuration: 1.5) {
            self.didTapGreen.layer.backgroundColor = UIColor.clear.cgColor
            let val = self.progressView.progress + 0.1
            self.progressView.setProgress(val, animated: true)
            if(self.progressView.progress == 1.0)
               {
                self.progressBarTimer.invalidate()
                self.isRunning = false
               }
        }
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseIn) {
            self.progressView.transform = .identity
            self.btnCheck.isSelected = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
            didTapGreen.isHidden = true
            btnPlay.alpha = 0.0
            viewPay.isHidden = false
            
            UIView.animate(withDuration: 1.0) {
                self.btnPlay.alpha = 1.0
            }
        }
        
       }
    
    //MARK: IBAction

    @IBAction func didTapbtnGreenButtom(_ sender: UIButton) {
        self.btnCheck.isHidden = false
        btnGreenButtom.isHidden = true
        lblDownload.isHidden = true
        lblMB.text = "10MB/30MB"
        if(isRunning) {
                   progressBarTimer.invalidate()
               } else {
               progressView.progress = 0.0
                   self.progressBarTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(CandyBustVC.updateProgressView), userInfo: nil, repeats: true)
               if(isRed) {
                   progressView.progressTintColor = #colorLiteral(red: 0.114330776, green: 0.585216701, blue: 0.9902330041, alpha: 0.4568792684)
                   progressView.progressViewStyle = .default

               } else {
                   progressView.trackTintColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
                   progressView.progressTintColor = UIColor.green
                   progressView.progressViewStyle = .bar
                   
               }
               isRed = !isRed
               }
               isRunning = !isRunning
    }
    
    @IBAction func isPlay(_ sender: Any) {
        let halfScreenVC = self.storyboard?.instantiateViewController(withIdentifier: "PopUpVC") as! PopUpVC
        let navRoot = UINavigationController(rootViewController: halfScreenVC)
           self.present(navRoot, animated: true)
    }
}
