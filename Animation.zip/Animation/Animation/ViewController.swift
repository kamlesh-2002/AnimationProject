//
//  ViewController.swift
//  Animation
//
//  Created by hb on 08/09/23.
//

import UIKit
import Hero

class ViewController: UIViewController {

    @IBOutlet weak var yellowView: UIView!
    @IBOutlet weak var topOrangeView: UIView!
    @IBOutlet weak var greenView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        greenView.layer.cornerRadius = 25
        yellowView.layer.cornerRadius = 20
        self.hero.isEnabled = true
        self.navigationController?.hero.isEnabled = true
        yellowView.hero.id = "YellowAnimation"
        greenView.hero.id = "GreenAnimation"
    }

    @IBAction func btnGreen(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CandyBustVC") as! CandyBustVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
