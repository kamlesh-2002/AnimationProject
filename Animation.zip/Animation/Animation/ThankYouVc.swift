//
//  ThankYouVc.swift
//  Animation
//
//  Created by hb on 11/09/23.
//

import UIKit

class ThankYouVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
