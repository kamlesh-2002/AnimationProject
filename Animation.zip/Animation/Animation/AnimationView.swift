//
//  AnimationView.swift
//  Animation
//
//  Created by hb on 09/09/23.
//

import UIKit

class AnimationView: UIView {

}
